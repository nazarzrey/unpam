<!DOCTYPE html>
<html>
<body>
<ul>
  <li><a href="<?= base_url("nama")?>">Cek Nama & Dosen</a></li>
  <li><a href="<?= base_url("absenlog")?>">Log Absen</a></li>
  <li><a href="<?= base_url("absendosen")?>">Absen Dosen</a></li>
  <li><a href="<?= base_url("login")?>">Absen MahaSiswa</a></li>
  <li><a href="<?= base_url("url")?>">Cek by URL</a></li>
  <li><a href="<?= base_url("grup")?>">Grup Absen</a></li>
</ul>
</body>
</html>


