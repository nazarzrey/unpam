
<head>
<script type="text/javascript" language="javascript">
var randomlinks=new Array("https://shope.ee/3VLdNZGvtF", "https://shope.ee/40HtydSr3p", "https://tokopedia.link/oCNhqJEGIGb")
location.href = randomlinks[Math.floor(Math.random()*randomlinks.length)];
</script>
</head>